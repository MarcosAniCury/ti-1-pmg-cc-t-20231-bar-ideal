[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10870815&assignment_repo_type=AssignmentRepo)
# BestPub
O objetivo do projeto é desenvolver uma solução digital para o problema de dificultade em encontrar o bar ideal para cada um.

## Alunos integrantes da equipe

* Gabriel Marques da Cunha
* João Victor Ferreira Pena
* Marcos Ani Cury Vinagre Silva

## Professores responsáveis

* Rommel Vieira Carneiro
* Nome completo do professor 2

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.

Link do site: https://ti-1-pmg-cc-t-20231-bar-ideal.marcosanicury.repl.co