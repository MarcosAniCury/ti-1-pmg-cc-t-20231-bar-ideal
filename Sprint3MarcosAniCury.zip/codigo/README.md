# Código do Projeto

Mantenha neste diretório todo o código fonte do projeto. 

Se necessário, descreva neste arquivo aspectos relevantes da estrutura de diretórios criada para organização do código.

- Enquanto não for adicionado o arquivo index acessar o arquivo home.html dentro da pasta views